"""MelodyV3 — 酷狗+网易云+B站 三源聚合桌面播放器"""

import http.server
import urllib.request
import urllib.parse
import subprocess
import json
import os
import sys
import threading
import time
import socket
import hashlib

# ═══════════════════════════════════════════════
# 配置常量
# ═══════════════════════════════════════════════

PORT = 21345
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
PL_FILE = os.path.join(os.path.expanduser("~"), ".melody3_playlist.json")
WBI_IDX = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
           27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13]


def base_dir():
    """返回资源目录（兼容 PyInstaller 打包）"""
    if getattr(sys, 'frozen', False):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


# ═══════════════════════════════════════════════
# BilibiliSigner — B站 WBI 签名
# ═══════════════════════════════════════════════

class BilibiliSigner:
    def __init__(self):
        self._key = None

    def _fetch_key(self):
        try:
            req = urllib.request.Request(
                "https://api.bilibili.com/x/web-interface/wbi/index/nav",
                headers={"User-Agent": UA, "Referer": "https://www.bilibili.com"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())["data"]["wbi_img"]
            raw = data["img_url"].split("/")[-1].split(".")[0] + \
                  data["sub_url"].split("/")[-1].split(".")[0]
            self._key = "".join(raw[i] for i in WBI_IDX)
        except Exception:
            self._key = ""

    @property
    def key(self):
        if self._key is None:
            self._fetch_key()
        return self._key

    def sign(self, params):
        k = self.key
        if not k:
            return urllib.parse.urlencode(params)
        params["wts"] = int(time.time())
        sqs = "&".join(f"{a}={params[a]}" for a in sorted(params.keys()))
        params["w_rid"] = hashlib.md5((sqs + k).encode()).hexdigest()
        return urllib.parse.urlencode(params)


# 全局单例
signer = BilibiliSigner()


# ═══════════════════════════════════════════════
# PlaylistStore — 歌单持久化
# ═══════════════════════════════════════════════

class PlaylistStore:
    @staticmethod
    def load():
        try:
            with open(PL_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    @staticmethod
    def save(data):
        try:
            with open(PL_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
        except Exception:
            pass


# ═══════════════════════════════════════════════
# HttpProxy — 上游 HTTP 请求
# ═══════════════════════════════════════════════

class HttpProxy:
    @staticmethod
    def get(url, referer=None, timeout=15):
        headers = {"User-Agent": UA}
        if referer:
            headers["Referer"] = referer
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read(), r.headers.get_content_type(), r.status
        except urllib.request.HTTPError as e:
            try:
                return e.read(), e.headers.get_content_type(), e.code
            except Exception:
                return b"{}", "application/json", e.code
        except Exception:
            return b"{}", "application/json", 502



# ═══════════════════════════════════════════════
# RequestHandler — HTTP 请求处理
# ═══════════════════════════════════════════════

class RequestHandler(http.server.BaseHTTPRequestHandler):

    # ── 路由表 ──
    ROUTES = [
        ("/api/playlist", "GET",  "_handle_playlist_get"),
        ("/api/playlist", "POST", "_handle_playlist_post"),
        ("/proxy/",       "GET",  "_handle_proxy"),
        ("/bl-audio/",    "GET",  "_handle_bl_audio"),
        ("/bl/",          "GET",  "_handle_bl_api"),
    ]

    def log_message(self, *args):
        pass

    def _reply(self, body, content_type="application/json", status=200,
               extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        try:
            self.end_headers()
            data = body if isinstance(body, bytes) else body.encode()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def _route(self, method):
        path = self.path
        for prefix, verb, handler_name in self.ROUTES:
            if method == verb and path.startswith(prefix):
                handler = getattr(self, handler_name)
                handler(path, prefix)
                return
        self.send_response(404)
        self.end_headers()

    def _handle_playlist_get(self, path, prefix):
        data = json.dumps(PlaylistStore.load(), ensure_ascii=False).encode()
        self._reply(data)

    def _handle_playlist_post(self, path, prefix):
        try:
            length = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(length))
            PlaylistStore.save(data)
            self._reply(b"ok")
        except Exception:
            self._reply(b"err", content_type="text/plain")

    def _handle_proxy(self, path, prefix):
        url = urllib.parse.unquote(path[len(prefix):])
        body, ct, status = HttpProxy.get(url)
        self._reply(body, ct or "application/json", status=status)

    def _handle_bl_audio(self, path, prefix):
        url = "https://" + path[len(prefix):]
        req_headers = {
            "User-Agent": UA,
            "Referer": "https://www.bilibili.com",
            "Origin": "https://www.bilibili.com",
            "Accept": "*/*",
        }
        req = urllib.request.Request(url, headers=req_headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                # 先发 HTTP 响应头
                ct = r.headers.get_content_type() or "audio/mp4"
                cl = r.headers.get("Content-Length")
                self.send_response(r.status)
                self.send_header("Content-Type", ct)
                self.send_header("Access-Control-Allow-Origin", "*")
                if cl:
                    self.send_header("Content-Length", cl)
                self.end_headers()
                # 再流式发送 body
                start = time.time()
                while True:
                    if time.time() - start > 60:
                        break
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError,
                            ConnectionAbortedError):
                        break
        except urllib.request.HTTPError as e:
            self.send_response(e.code)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except Exception:
            try:
                self.send_response(502)
                self.send_header("Content-Type", "text/plain")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
            except Exception:
                pass

    def _handle_bl_api(self, path, prefix):
        raw = "/" + path[len(prefix):]
        if "?" in raw:
            base, qs = raw.split("?", 1)
            params = dict(urllib.parse.parse_qsl(qs))
        else:
            base, params = raw, {}
        qs = signer.sign(params)
        url = f"https://api.bilibili.com{base}?{qs}"
        body, ct, status = HttpProxy.get(url, referer="https://www.bilibili.com")
        self._reply(body, ct or "application/json", status=status)

    def _serve_html(self):
        fp = os.path.join(base_dir(), "kugou-player.html")
        with open(fp, "rb") as f:
            self._reply(f.read(), "text/html; charset=utf-8")

    # ── HTTP 方法 ──

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._serve_html()
            return
        self._route("GET")

    def do_POST(self):
        self._route("POST")


# ═══════════════════════════════════════════════
# AppServer — 服务生命周期
# ═══════════════════════════════════════════════

class AppServer:
    @staticmethod
    def kill_port():
        if sys.platform != "win32":
            return
        try:
            r = subprocess.run(
                f'netstat -ano | findstr :{PORT}',
                capture_output=True, text=True, shell=True)
            killed = set()
            for line in r.stdout.strip().split('\n'):
                parts = line.strip().split()
                if parts and 'LISTENING' in line:
                    pid = parts[-1]
                    if pid not in killed:
                        subprocess.run(
                            f'taskkill /f /pid {pid}',
                            capture_output=True, shell=True)
                        killed.add(pid)
        except Exception:
            pass

    @staticmethod
    def start():
        class ReuseServer(http.server.ThreadingHTTPServer):
            allow_reuse_address = True
            daemon_threads = True

            def server_bind(self):
                self.socket.setsockopt(socket.SOL_SOCKET,
                                       socket.SO_REUSEADDR, 1)
                super().server_bind()

        ReuseServer(("127.0.0.1", PORT), RequestHandler).serve_forever()

    @staticmethod
    def wait(timeout=10):
        for _ in range(timeout * 5):
            try:
                urllib.request.urlopen(
                    f"http://127.0.0.1:{PORT}/", timeout=0.5)
                return True
            except Exception:
                time.sleep(0.2)
        return False


# ═══════════════════════════════════════════════
# 主入口
# ═══════════════════════════════════════════════

def main():
    AppServer.kill_port()
    time.sleep(1)

    threading.Thread(target=AppServer.start, daemon=True).start()

    if not AppServer.wait():
        import ctypes
        ctypes.windll.user32.MessageBoxW(
            0, "服务器启动失败，请重启电脑后重试", "MelodyV3", 0x10)
        sys.exit(1)

    print(f"MelodyV3 → http://localhost:{PORT}")

    import webview
    webview.create_window("MelodyV3", f"http://localhost:{PORT}",
                          width=1200, height=780, min_size=(800, 500))
    webview.start()


if __name__ == "__main__":
    main()
